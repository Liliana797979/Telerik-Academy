let person; // not defined so the value is undefined
let age = undefined; // explicitly assign undefined value

console.log(person);
console.log(person === age); // These are equal

person = 'Peter'; // you could assign a value later

console.log(person);
