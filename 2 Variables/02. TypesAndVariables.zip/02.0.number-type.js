let radius = 6;

let circumference = 2 * Math.PI * radius;
let area = (Math.PI * radius * radius) / 2;

console.log('Circumference ' + circumference);
console.log('Area ' + area);