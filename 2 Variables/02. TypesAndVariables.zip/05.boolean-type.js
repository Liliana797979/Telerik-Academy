let n1 = 25;
let n2 = 30;

let greater = n1 > n2;

console.log('n1 = ' + n1 + ' is the greater number: ' + greater);

// parsing to boolean

let zeroToBoolean = Boolean(0);
let twoToBoolean = Boolean(2);
let emptyStringToBoolean = Boolean('');

console.log('zeroToBoolean: ', zeroToBoolean);
console.log('twoToBoolean: ', twoToBoolean);
console.log('emptyStringToBoolean: ', emptyStringToBoolean);
