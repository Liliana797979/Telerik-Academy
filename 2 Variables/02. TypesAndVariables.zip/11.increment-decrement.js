let counter = 0;

// this will output 0 because the postfix operator will increment after the operation is performed 
console.log(counter++);

// the counter is already incremented with one
console.log(counter);

// this will output 2 because the prefix operator will increment before the operation is performed
console.log(++counter);
