let person = 'Peter'; // string
let age = 23; // number
let isUnder30 = true; // boolean

let ageIn5year = age + 5;

console.log(person + ' is ' + age + '  years old.');
console.log('He is under 30: ' + isUnder30);
console.log('In 5 years he will be ' + ageIn5year);
