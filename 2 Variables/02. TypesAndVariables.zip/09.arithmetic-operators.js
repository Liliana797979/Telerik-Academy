let numberOne = 1;
let numberTwo = 2;

let sum = numberOne + numberTwo;
let diff = numberTwo - numberOne;
let mult = numberOne * numberTwo;
let div = numberOne / numberTwo;

console.log(`Sum: ${sum}`);
console.log(`Subtract: ${diff}`);
console.log(`Multiply: ${mult}`);
console.log(`Divide: ${div}`);
