let number = 7;

if (number % 2 === 0) {
  console.log('This number is even.');
} else {
  console.log('This number is odd.');
}