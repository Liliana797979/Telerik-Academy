let first = 13;
let second = 17;

if (first === second) {
  console.log('This two numbers are equal.');
} else {
  if (first > second) {
    console.log('The first number is greater than the second.');
  } else {
    console.log('The second number is greater than the first.');
  }
}