let age = 25;
let under30 = false;

if (age < 30) {
  under30 = true;
}

console.log('Age is under 30: ' + under30);